<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('material', function (Blueprint $table) {
            $table->string('kondisi')->nullable()->change();
            $table->string('jenis')->nullable();
            $table->integer('jumlah')->nullable();
            $table->string('lokasi')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('material', function (Blueprint $table) {
            $table->boolean('kondisi');
            $table->dropColumn('jenis');
            $table->dropColumn('jumlah');
        });
    }
};
