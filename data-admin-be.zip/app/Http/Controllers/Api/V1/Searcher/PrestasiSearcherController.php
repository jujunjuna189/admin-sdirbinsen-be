<?php

namespace App\Http\Controllers\Api\V1\Searcher;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PrestasiSearcherController extends Controller
{
    //
}
